# COMP_EECE_7or8740_NNs
Repository of the codes for COMP/EECE 7o/8740 Neural Networks
